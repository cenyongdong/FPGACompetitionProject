# 核心源码归档

从 software/pose180_pipeline/src/README.md 开始阅读；输入说明与审查记录在 software/pose180_pipeline/resident/。

保留原仓库相对路径，CMake 目标为 pose180_demo（ARM64）和 pose180_demo_mock（本地）。含两种输入、SDK 所有权、HDMI／PC、构建配置和离线检查。不含模型权重、SDK 安装文件、运行日志、凭据或新 PL 开发。正式硬件继续使用 default_boot.json 对应的既有合格版本；完整演示包含其 BOOT 备份。

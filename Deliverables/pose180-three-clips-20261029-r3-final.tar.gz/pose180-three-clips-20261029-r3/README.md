# pose180-three-clips-20261029-r3

首次部署请先读 [部署与演示步骤](DEPLOY.md)。本包由整理后的 `src/`、`control/`、`host/` 源码构建，源码快照见 `core-sources.tar.gz`。

模型：`piw24_pose180_shared epoch99`。TopK=3、严格 score > 0.2、CPU 多人跟踪／滤波。默认输入：`official_dataset`。

双输入：`sh start-live.sh` 接实时CSI；`sh start-dataset.sh` 对包内官方CSI执行新推理，EOF正常退出。数据来源：一次启动，按以下顺序在同一 SDK 进程内播放，片段之间不重启开发板；每段切换重置跟踪状态。

| 顺序 | 人数 | 官方来源 | 样本范围 | 展示时长 |
|---|---|---|---|---|
| 1 | 1 | train / S51_10 | 10–159 | 10.0 秒 |
| 2 | 2 | train / S52_16 | 97–231 | 9.0 秒 |
| 3 | 3 | train / S23_43 | 94–228 | 9.0 秒 |

每段 15 Hz 播放时长为演示时间线，不作为原始采集时长。片段边界有约 0.1 秒收尾间隔。

训练集演示不计独立测试精度。

所用构建与本地检查见validation记录；本次最终归档未重新部署；相同板端程序、模型和数据的最近既有运行已确认 420 帧推理、HDMI 与 PC 输出并安全退出。保留原HDMI和PC性能指标栏。

以root执行 `sh check.sh` 核对，`sh start.sh` 手动开始，`sh status.sh` 查看，`sh stop.sh` 请求正常停止。默认处理期为0秒（0表示手动停止）；可用 `sh start.sh --seconds 300` 显式指定。

一次只运行一个输入；切换前须安全停止、确认SDK／HDMI关闭，再prepare-boot、正常重启并重新check。每次FPGA配置只使用一次功能启动入口。`release_blocked`表示完成未证明，必须保留资源与独占，不强杀、不自动重试或切换模型。

未知boot_id按STARTUP-GUIDE.md处理，不跳过BOOT身份检查。包内BOOT仅为备份，不会自动安装或重启。PC运行 `start-pc.ps1`；停止PC不影响板端。

完整操作与边界见 [启动说明](STARTUP-GUIDE.md)；实际构建、故障注入与模型身份在 `validation/`。

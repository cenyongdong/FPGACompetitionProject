"""Export the validated single-image shared refiner; keep both TopK operations."""
import os
os.environ.setdefault('PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION','python')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback

ROOT=Path('/public/cyd/Person-in-WiFi-3D-repo')
sys.path.insert(0,str(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def diff(a,b):
    import numpy as np
    return dict(max_abs=float(np.abs(a.astype('f8')-b.astype('f8')).max()),
                bitwise=a.tobytes()==b.tobytes(),finite=bool(np.isfinite(a).all() and np.isfinite(b).all()))

def main():
    import numpy as np
    np.__dict__.setdefault('object',object)
    import torch
    import onnx
    from onnx import numpy_helper
    import onnxruntime as ort
    from mmcv import Config
    from mmcv.runner import load_checkpoint
    from opera.models import build_model
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    out=parser.parse_args().output.resolve()
    assert out.parent==ROOT/'exportONNX' and not (out/'preflight.json').exists()
    started=time.monotonic();os.chdir(ROOT)
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(0)
    checkpoint=ROOT/'result/code_faithful/best_mpjpe_epoch_442.pth'
    pins={'result/code_faithful/best_mpjpe_epoch_442.pth':'6493e2250b83aef59ce4825e15d2d0043a59490275f75933f9a59867867d3221',
          'result/code_faithful/petr_wifi.py':'9851f018164c56736c246246a199c4d5eba0d26c1bc0a98dcb40c6bf9059229c',
          'opera/models/utils/transformer.py':'74ffb67cda14faf475ae1b73f8b0496beac67a7bd6aeab61cc9eb37cfdd5ae20',
          'opera/models/dense_heads/petr_head.py':'5758dc05c7c8e07370b8178f2782d5828b0a9e19b94de363c3a9c9669b57fdad',
          'exportONNX/scatter-add-20261014-r1/person_in_wifi_2024_best_epoch442_full_noscatter.onnx':'a8c3261b614cc14e6b4818d0efaf8a61dc3127bbe08020096600e654bc1b9c75'}
    for name,h in pins.items():assert sha(ROOT/name)==h,name
    for name,relative in [('transformer.py','opera/models/utils/transformer.py'),('petr_head.py','opera/models/dense_heads/petr_head.py')]:
        (out/name).write_bytes((ROOT/relative).read_bytes())
    cfg=Config.fromfile(str(ROOT/'result/code_faithful/petr_wifi.py'))
    cfg.model.train_cfg=None;cfg.model.backbone.init_cfg=None
    model=build_model(cfg.model,test_cfg=cfg.get('test_cfg')).eval()
    load_checkpoint(model,str(checkpoint),map_location='cpu',strict=True)
    assert model.bbox_head.num_query==100 and model.bbox_head.num_keypoints==14
    assert model.bbox_head.transformer.refine_decoder.num_layers==2

    class FullGraph(torch.nn.Module):
        def __init__(self,detector):
            super().__init__();self.detector=detector
            self.head=detector.head;self.bbox_head=detector.bbox_head
            self.refine_kpt_branches=detector.bbox_head.refine_kpt_branches
        def components(self,x):
            features=self.head(x)
            classes,kpts,_,_,memory=self.bbox_head(features,None)
            scores,indices=classes[-1,0].sigmoid().reshape(-1).topk(100)
            return scores,kpts[-1,0][indices],memory
        def forward(self,x):
            scores,selected,memory=self.components(x)
            image_indices=torch.zeros(100,dtype=torch.long,device=selected.device)
            states,initial,references=self.bbox_head.transformer.forward_refine(
                memory,selected.detach(),image_indices,kpt_branches=self.refine_kpt_branches)
            # Same as the validated PETRHead: evaluate once on the shared view,
            # then add to the preceding per-candidate reference in original order.
            final_features=states[-1].permute(1,0,2)[:1]
            poses=self.refine_kpt_branches[-1](final_features)+references[-2]
            return scores.unsqueeze(0),poses.unsqueeze(0)

    wrapped=FullGraph(model).eval()
    paired=ROOT/'result/shared_refine_20261014_r1'
    assert json.loads((paired/'summary.json').read_text())['frames']==7824
    inputs=np.load(paired/'inputs.npy',mmap_mode='r')
    assert sha(paired/'inputs.npy')=='2cb53a23c6b2b53c5e30ac614d6742eded9d7b36bb6de9c0d67fbc7b0b2781f7'
    names=(ROOT/'data/wifipose/test_data/test_data_list.txt').read_text().splitlines()
    indices=sorted(set(np.linspace(0,7823,27,dtype=int).tolist()+[i for i,n in enumerate(names) if n in ('S11_01_308','S11_01_309','S11_01_310')]))
    xs=np.array(inputs[indices],copy=True);np.save(out/'verification-inputs.npy',xs)
    save(out/'preflight.json',dict(pins=pins,python=sys.executable,torch=torch.__version__,
        onnx=onnx.__version__,onnxruntime=ort.__version__,samples=len(indices),budget_seconds=600,
        TopK=2,candidates=100,training=False,weights_changed=False,shared_feature_batch=1,
        gate='ORT new-vs-noscatter scores bitwise; all coordinates absolute <=1e-5; same-runtime native wrapper bitwise',
        fixed_FP32_ports=[[1,180,60],[1,100],[1,100,14,3]],opset=11))
    filename='person_in_wifi_2024_best_epoch442_full_shared.onnx';path=out/filename
    with torch.no_grad():
        torch.onnx.export(wrapped,(torch.from_numpy(xs[:1]),),str(path),opset_version=11,
            input_names=['csi_tokens'],output_names=['scores','poses'],do_constant_folding=True)
    graph=onnx.load(str(path));onnx.checker.check_model(graph)
    def ports(vs):return [(v.name,[d.dim_value for d in v.type.tensor_type.shape.dim],v.type.tensor_type.elem_type) for v in vs]
    assert ports(graph.graph.input)==[('csi_tokens',[1,180,60],1)]
    assert ports(graph.graph.output)==[('scores',[1,100],1),('poses',[1,100,14,3],1)]
    counts=dict(Counter(n.op_type for n in graph.graph.node))
    assert counts.get('ScatterND',0)==0 and counts.get('TopK',0)==2 and counts.get('GatherElements',0)==1
    inferred=onnx.shape_inference.infer_shapes(graph)
    shapes={v.name:[d.dim_value for d in v.type.tensor_type.shape.dim] for v in list(inferred.graph.value_info)+list(inferred.graph.input)+list(inferred.graph.output)}
    shapes.update({v.name:list(v.dims) for v in inferred.graph.initializer})
    ref_matmul=[dict(name=n.name,input_shapes=[shapes.get(i) for i in n.input]) for n in inferred.graph.node
                if n.op_type=='MatMul' and ('refine_decoder' in n.name or 'refine_kpt' in n.name)]
    save(out/'refine-matmul-shapes.json',ref_matmul)
    options=ort.SessionOptions();options.intra_op_num_threads=1;options.inter_op_num_threads=1
    options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL
    old_path=ROOT/'exportONNX/scatter-add-20261014-r1/person_in_wifi_2024_best_epoch442_full_noscatter.onnx'
    sessions={name:ort.InferenceSession(str(p),sess_options=options,providers=['CPUExecutionProvider']) for name,p in [('noscatter',old_path),('shared',path)]}
    verification=[]
    for j,index in enumerate(indices):
        assert time.monotonic()-started<600
        x=xs[j:j+1];t=torch.from_numpy(x)
        with torch.no_grad():
            python_values=[v.numpy().copy() for v in wrapped(t)]
            scores,selected,memory=wrapped.components(t)
            native=model.bbox_head.forward_refine(memory,(selected,None,torch.ones_like(selected)),None,None)[-1].unsqueeze(0).numpy().copy()
        values={name:s.run(['scores','poses'],{'csi_tokens':x}) for name,s in sessions.items()}
        values['pytorch']=python_values
        folder=out/('sample-'+str(index));folder.mkdir()
        for mode,arrays in values.items():
            for n,a in zip(('scores','poses'),arrays):np.save(folder/(mode+'.'+n+'.npy'),a)
        np.save(folder/'native.poses.npy',native)
        rec=dict(index=index,sample=names[index],
            native_vs_wrapper=diff(native,python_values[1]),
            shared_vs_noscatter=[diff(a,b) for a,b in zip(values['shared'],values['noscatter'])],
            shared_vs_CPU_pytorch=[diff(a,b) for a,b in zip(values['shared'],python_values)])
        verification.append(rec);save(out/'verification.json',verification)
        assert rec['native_vs_wrapper']['bitwise']
        assert all(c['finite'] for label in ('shared_vs_noscatter','shared_vs_CPU_pytorch') for c in rec[label])
        assert rec['shared_vs_noscatter'][0]['bitwise'] and rec['shared_vs_noscatter'][1]['max_abs']<=1e-5
        print(json.dumps(dict(index=index,sample=names[index],comparisons=rec['shared_vs_noscatter'])),flush=True)
    for name,h in pins.items():assert sha(ROOT/name)==h,name
    result=dict(status='complete_shared_full_graph_exported_verified',file=filename,sha256=sha(path),bytes=path.stat().st_size,
        nodes=len(graph.graph.node),initializers=len(graph.graph.initializer),operators=counts,samples=len(indices),
        maximum_shared_vs_noscatter=[max(v['shared_vs_noscatter'][i]['max_abs'] for v in verification) for i in (0,1)],
        native_wrapper_all_bitwise=True,weights_changed=False,retrained=False,seconds=time.monotonic()-started)
    save(out/'summary.json',result)
    save(out/'files.json',{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ('stdout.log','stderr.log','files.json','execution.json')})
    print(json.dumps(result),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if '--output' in sys.argv:
            out=Path(sys.argv[sys.argv.index('--output')+1]);save(out/'failure.json',dict(error=repr(error),traceback=traceback.format_exc()))
        raise

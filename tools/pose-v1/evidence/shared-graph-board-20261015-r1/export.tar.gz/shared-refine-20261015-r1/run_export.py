"""One bounded CPU-only export with exact logs and complete archive."""
import hashlib,json,os
from pathlib import Path
import signal,subprocess,sys,tarfile,time
out=Path(__file__).resolve().parent
assert out.parent==Path('/public/cyd/Person-in-WiFi-3D-repo/exportONNX')
assert not (out/'execution.json').exists()
info=dict(status='starting',cwd=str(out.parent.parent),timeout_seconds=650,CPU_only=True,wrapper_pid=os.getpid())
def save(): (out/'execution.json').write_text(json.dumps(info,indent=2)+'\n')
save();start=time.monotonic()
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (out/'stdout.log').open('xb') as so,(out/'stderr.log').open('xb') as se:
    p=subprocess.Popen([sys.executable,'-u',str(out/'export_shared.py'),'--output',str(out)],
                       cwd=info['cwd'],env=env,stdout=so,stderr=se,start_new_session=True)
    info.update(status='running',child_pid=p.pid,process_group=p.pid);save()
    try:code=p.wait(timeout=650)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGTERM)
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        code=124
    finally:
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
info.update(status='complete' if code==0 else 'failed',exit_code=code,seconds=time.monotonic()-start);save()
(out/'exit-code.txt').write_text(str(code)+'\n')
archive=out.parent/(out.name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'x:gz',compresslevel=1) as t:t.add(out,arcname=out.name)
h=hashlib.sha256(archive.read_bytes()).hexdigest()
identity=dict(path=str(archive),sha256=h,bytes=archive.stat().st_size,execution=info)
(out.parent/(out.name+'.archive.json')).write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity),flush=True)
sys.exit(code)

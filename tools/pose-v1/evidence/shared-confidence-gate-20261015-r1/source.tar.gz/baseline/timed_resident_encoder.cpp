// 视频模块：有界NV12及V4L2编码；缓冲所有权、正常drain与异常回收保持。
// 依赖通过本模块头文件声明；公开接口及异常传播遵循冻结基线。

// Isolated, finite V4L2 encoder test. No Icraft, HDMI, registers or camera MMU.
#include "vpu_resident_encoder.hpp"
#include <thread>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
    constexpr unsigned W = 1280, H = 720, FPS = 10;
    constexpr auto IN = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
    constexpr auto OUT = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    // Actual vendor reference mvx-v4l2-controls.h: Q16 frame rate.
    constexpr unsigned MVE_FRAME_RATE = V4L2_CTRL_CLASS_MPEG + 0x2000;
    void require(bool ok, const char* message) {
        if (!ok) throw std::runtime_error(message);
    }

    int call(int fd, unsigned long op, void* p) {
        int r;
        do {
            r = ioctl(fd, op, p);
        }

        while (r < 0 && errno == EINTR);
        return r;
    }

    void checked(int fd, unsigned long op, void* p, const char* name) {
        if (call(fd, op, p) < 0) throw std::runtime_error(std::string(name) + ": " + strerror(errno));
    }

    std::string fourcc(unsigned v) {
        std::string s;
        for (int i = 0; i < 4; ++i) s += char((v >>(8 * i)) & 255);
        return s;
    }

    void format(std::ostream& log, const v4l2_format& f) {
        const auto& p = f.fmt.pix_mp;
        log << "{\"event\":\"format\",\"type\":" << f.type << ",\"fourcc\":\"" << fourcc(p.pixelformat) << "\",\"width\":" <<
        p.width << ",\"height\":" << p.height << ",\"planes\":" << unsigned(p.num_planes) << ",\"field\":" << p.field <<
        ",\"colorspace\":" << p.colorspace << ",\"ycbcr_enc\":" << unsigned(p.ycbcr_enc) << ",\"quantization\":" <<
        unsigned(p.quantization) << ",\"xfer_func\":" << unsigned(p.xfer_func) << ",\"layout\":[";
        for (unsigned i = 0; i < p.num_planes; ++i) {
            if (i) log << ',';
            log << "{\"stride\":" << p.plane_fmt[i].bytesperline << ",\"size\":" << p.plane_fmt[i].sizeimage << '}';
        }

        log << "]}" << '\n';
    }

    struct Plane {
        void* ptr = MAP_FAILED;
        unsigned size = 0;
        unsigned mmapCookie = 0;
    };
    // Read-only diagnostics. Snapshots perturb timing slightly, never reclaim or
    // compact memory and never infer that a later allocation must succeed.
    struct MemoryAudit {
        std::filesystem::path dir;
        std::ostream& log;
        unsigned count = 0;
        MemoryAudit(const std::filesystem::path& dest, std::ostream& trace) : dir(dest / "memory"), log(trace) {
            require(std::filesystem::create_directory(dir), "memory audit directory creation failed");
        }

        void take(const std::string& stage) {
            require(count < 24, "memory snapshot bound exceeded");
            auto prefix = std::to_string(count ++) + "-" + stage;
            for (const char* name : { "buddyinfo", "pagetypeinfo", "meminfo", "vmstat" }) {
                std::ifstream input(std::string("/proc/") + name);
                std::ofstream output(dir / (prefix + "-" + name + ".txt"));
                require(bool(input) && bool(output), "memory snapshot open failed");
                output << input.rdbuf();
                require(bool(output), "memory snapshot write failed");
            }
            log << "{\"event\":\"memory_snapshot\",\"stage\":\"" << stage << "\",\"prefix\":\"" << prefix << "\",\"time_ns\":" <<
            std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count() <<
            "}" << '\n';
        }

    };
    struct Queue {
        int fd;
        v4l2_buf_type type;
        unsigned planes;
        bool streaming = false;
        std::ostream* trace = nullptr;
        std::vector<std::vector<Plane >> buffers;
        std::vector<bool> ownedByDriver;
        Queue(int f, v4l2_buf_type t, unsigned p) : fd(f), type(t), planes(p) {} ~Queue() {
            if (streaming) {
                int result = call(fd, VIDIOC_STREAMOFF, & type);
                int error = result < 0 ? errno : 0;
                if (trace) * trace << "{\"event\":\"abort_streamoff\",\"type\":" << type << ",\"result\":" << result << ",\"errno\":" <<
                error << "}" << '\n';
            }
            for (auto & b : buffers) for (auto & p : b) if (p.ptr != MAP_FAILED) munmap(p.ptr, p.size);
            if (!buffers.empty()) {
                v4l2_requestbuffers r {};
                r.type = type;
                r.memory = V4L2_MEMORY_MMAP;
                call(fd, VIDIOC_REQBUFS, & r);
            }
        }

        // 1. 保留协商出的两缓冲和QUERYBUF不透明cookie；不猜测物理地址。
        void allocate(std::ostream& log, MemoryAudit& audit) {
            trace = & log;
            const auto label = type == IN ? "raw" : "capture";
            audit.take(std::string(label) + "-before-reqbufs");
            // Isolated startup footprint candidate, based on r7 allocation snapshots.
            v4l2_requestbuffers r {};
            r.type = type;
            r.memory = V4L2_MEMORY_MMAP;
            r.count = 2;
            checked(fd, VIDIOC_REQBUFS, & r, "REQBUFS");
            require(r.count == 2, "resident buffer negotiation differs from2");
            audit.take(std::string(label) + "-after-reqbufs");
            buffers.resize(r.count);
            ownedByDriver.resize(r.count, false);
            for (unsigned i = 0; i < r.count; ++i) {
                v4l2_buffer b {};
                v4l2_plane p[VIDEO_MAX_PLANES] {};
                b.type = type;
                b.memory = V4L2_MEMORY_MMAP;
                b.index = i;
                b.length = planes;
                b.m.planes = p;
                checked(fd, VIDIOC_QUERYBUF, & b, "QUERYBUF");
                require(b.length == planes, "query plane count changed");
                describe("querybuf", b, p);
                buffers[i].resize(planes);
                for (unsigned j = 0; j < planes; ++j) {
                    require(p[j].length > 0 && p[j].length <= 16 * 1024 * 1024, "unbounded buffer");
                    auto& q = buffers[i][j];
                    q.size = p[j].length;
                    q.mmapCookie = p[j].m.mem_offset;
                    q.ptr = mmap(nullptr, q.size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, p[j].m.mem_offset);
                    require(q.ptr != MAP_FAILED, "mmap failed");
                    log << "{\"event\":\"buffer\",\"type\":" << type << ",\"index\":" << i << ",\"plane\":" << j << ",\"length\":" <<
                    q.size << ",\"mmap_cookie\":" << p[j].m.mem_offset << ",\"data_offset\":" << p[j].data_offset << "}" << '\n';
                }
            }
            size_t mapped = 0;
            for (const auto & buffer : buffers) for (const auto & plane : buffer) mapped += plane.size;
            log << "{\"event\":\"mapped_total\",\"type\":" << type << ",\"bytes\":" << mapped << ",\"buffers\":" << buffers.size() <<
            "}" << '\n';
            audit.take(std::string(label) + "-after-mmap");
        }

        void describe(const char* event, const v4l2_buffer& b, const v4l2_plane * p) const {
            if (!trace) return;
            * trace << "{\"event\":\"" << event << "\",\"type\":" << b.type << ",\"index\":" << b.index << ",\"memory\":" <<
            b.memory << ",\"flags\":" << b.flags << ",\"field\":" << b.field << ",\"sequence\":" << b.sequence << ",\"pts_us\":" <<
            b.timestamp.tv_sec * 1000000LL + b.timestamp.tv_usec << ",\"planes\":[";
            for (unsigned j = 0; j < b.length; ++j) {
                if (j) * trace << ',';
                * trace << "{\"length\":" << p[j].length << ",\"bytesused\":" << p[j].bytesused << ",\"data_offset\":" << p[j].data_offset <<
                ",\"mmap_cookie\":" << p[j].m.mem_offset << '}';
            }
            * trace << "]}" << '\n';
        }

        // 2. 仅CPU拥有的输入缓冲可以写入和提交；成功QBUF后归驱动拥有。
        void queue(unsigned i, const std::vector<unsigned > & used, unsigned frame = 0, int64_t ptsUs = - 1) {
            require(i < buffers.size() && used.size() == planes, "queue bounds");
            require(!ownedByDriver[i], "buffer still owned by driver before queue");
            v4l2_buffer b {};
            v4l2_plane p[VIDEO_MAX_PLANES] {};
            b.type = type;
            b.memory = V4L2_MEMORY_MMAP;
            b.index = i;
            b.length = planes;
            b.m.planes = p;
            b.field = V4L2_FIELD_NONE;
            if (ptsUs < 0) ptsUs = int64_t(frame) * 100000;
            b.timestamp.tv_sec = ptsUs / 1000000;
            b.timestamp.tv_usec = ptsUs % 1000000;
            for (unsigned j = 0; j < planes; ++j) {
                require(used[j] <= buffers[i][j].size, "queue size");
                p[j].length = buffers[i][j].size;
                p[j].bytesused = used[j];
                // Preserve QUERYBUF's opaque cookie as the shipped client does.
                // No physical address inference or allocation/capacity change.
                p[j].m.mem_offset = buffers[i][j].mmapCookie;
            }
            describe("qbuf_enter", b, p);
            checked(fd, VIDIOC_QBUF, & b, "QBUF");
            ownedByDriver[i] = true;
            describe("qbuf_return", b, p);
        }

        // 3. DQBUF成功后才归还缓冲所有权，异常原样停止。
        bool dequeue(v4l2_buffer& b, v4l2_plane * p) {
            b = {};
            b.type = type;
            b.memory = V4L2_MEMORY_MMAP;
            b.length = planes;
            b.m.planes = p;
            if (call(fd, VIDIOC_DQBUF, & b) < 0) {
                if (errno == EAGAIN) return false;
                if (trace) * trace << "{\"event\":\"dqbuf_error\",\"type\":" << type << ",\"errno\":" << errno << "}" << '\n';
                throw std::runtime_error(std::string("DQBUF: ") + strerror(errno));
            }
            require(b.index < buffers.size() && b.length == planes, "dequeue bounds");
            describe("dqbuf", b, p);
            require(ownedByDriver[b.index], "dequeued buffer not owned by driver");
            ownedByDriver[b.index] = false;
            require(!(b.flags& V4L2_BUF_FLAG_ERROR), "driver buffer error");
            return true;
        }

        void start() {
            checked(fd, VIDIOC_STREAMON, & type, "STREAMON");
            streaming = true;
            if (trace) * trace << "{\"event\":\"streamon\",\"type\":" << type << "}" << '\n';
        }

        void stop() {
            checked(fd, VIDIOC_STREAMOFF, & type, "STREAMOFF");
            streaming = false;
            if (trace) * trace << "{\"event\":\"streamoff\",\"type\":" << type << "}" << '\n';
        }

    };
    struct Device {
        int fd = - 1;
        ~Device() {
            if (fd >= 0) close(fd);
        }

    };
    void control(int fd, unsigned id, int value, std::ostream& log) {
        v4l2_queryctrl q {};
        q.id = id;
        checked(fd, VIDIOC_QUERYCTRL, & q, "QUERYCTRL");
        require(!(q.flags& V4L2_CTRL_FLAG_DISABLED) && value >= q.minimum && value <= q.maximum, "control unsupported/range");
        v4l2_control c {};
        c.id = id;
        c.value = value;
        checked(fd, VIDIOC_S_CTRL, & c, "S_CTRL");
        checked(fd, VIDIOC_G_CTRL, & c, "G_CTRL");
        require(c.value == value, "control readback differs");
        log << "{\"event\":\"control\",\"id\":" << id << ",\"value\":" << c.value << "}" << '\n';
    }

}

namespace pose::video {
    // 4. 固定格式协商、采样、编码和drain；所有预算与日志契约保持。
    EncodeResult encodeResident(const std::filesystem::path& dest, const ResidentOptions& options, ResidentProducer producer, PacketConsumer consumer, std::function<void() > onFirstCapture) {
        require(options.allowVpuStream, "explicit VPU authorization required");
        require(options.frameLimit >= 2 && options.frameLimit <= 1000, "resident frame limit outside2..1000");
        constexpr unsigned primeInputs = 2;
        require(bool(producer) && bool(consumer) && bool(onFirstCapture), "producer/consumer missing before device access");
        require(!std::filesystem::exists(dest), "output exists; preserve and stop");
        std::filesystem::create_directory(dest);
        std::ofstream log(dest / "events.jsonl");
        require(bool(log), "log open failed");
        MemoryAudit audit(dest, log);
        audit.take("entry");
        Device d;
        d.fd = open("/dev/video0", O_RDWR | O_NONBLOCK | O_CLOEXEC);
        require(d.fd >= 0, "open video0 failed");
        audit.take("device-open");
        v4l2_capability cap {};
        checked(d.fd, VIDIOC_QUERYCAP, & cap, "QUERYCAP");
        require(std::string(reinterpret_cast<char *>(cap.driver)) == "mvx", "driver identity changed");
        require(cap.device_caps& V4L2_CAP_VIDEO_M2M_MPLANE, "missing M2M MPLANE");
        log << "{\"event\":\"identity\",\"driver\":\"mvx\",\"version\":" << cap.version << ",\"device_caps\":" << cap.device_caps <<
        "}" << '\n';
        v4l2_format coded {};
        coded.type = OUT;
        coded.fmt.pix_mp.pixelformat = V4L2_PIX_FMT_H264;
        coded.fmt.pix_mp.width = W;
        coded.fmt.pix_mp.height = H;
        coded.fmt.pix_mp.num_planes = 1;
        coded.fmt.pix_mp.plane_fmt[0].sizeimage = 2 * 1024 * 1024;
        checked(d.fd, VIDIOC_S_FMT, & coded, "S_FMT H264");
        v4l2_format raw {};
        raw.type = IN;
        auto& rp = raw.fmt.pix_mp;
        rp.width = W;
        rp.height = H;
        rp.pixelformat = V4L2_PIX_FMT_NV12;
        rp.field = V4L2_FIELD_NONE;
        rp.colorspace = V4L2_COLORSPACE_SMPTE170M;
        rp.ycbcr_enc = V4L2_YCBCR_ENC_601;
        rp.quantization = V4L2_QUANTIZATION_LIM_RANGE;
        rp.xfer_func = V4L2_XFER_FUNC_709;
        checked(d.fd, VIDIOC_S_FMT, & raw, "S_FMT NV12");
        // This MVX driver leaves coded size at 2x2 when CAPTURE precedes raw.
        // Reapply coded format after raw as the shipped vendor Encoder does,
        // then read both formats again; never accept a mismatching size.
        coded.fmt.pix_mp.width = W;
        coded.fmt.pix_mp.height = H;
        coded.fmt.pix_mp.colorspace = V4L2_COLORSPACE_SMPTE170M;
        coded.fmt.pix_mp.ycbcr_enc = V4L2_YCBCR_ENC_601;
        coded.fmt.pix_mp.quantization = V4L2_QUANTIZATION_LIM_RANGE;
        coded.fmt.pix_mp.xfer_func = V4L2_XFER_FUNC_709;
        checked(d.fd, VIDIOC_S_FMT, & coded, "S_FMT H264 after NV12");
        checked(d.fd, VIDIOC_G_FMT, & raw, "G_FMT NV12");
        checked(d.fd, VIDIOC_G_FMT, & coded, "G_FMT H264");
        format(log, raw);
        format(log, coded);
        audit.take("formats");
        require(rp.width == W && rp.height == H && rp.pixelformat == V4L2_PIX_FMT_NV12 && rp.field == V4L2_FIELD_NONE, "raw format changed");
        require(rp.colorspace == V4L2_COLORSPACE_SMPTE170M && rp.ycbcr_enc == V4L2_YCBCR_ENC_601 && rp.quantization == V4L2_QUANTIZATION_LIM_RANGE, "raw colorimetry differs");
        require(rp.num_planes == 1 || rp.num_planes == 2, "unsupported NV12 plane layout");
        require(coded.fmt.pix_mp.pixelformat == V4L2_PIX_FMT_H264 && coded.fmt.pix_mp.num_planes == 1 && coded.fmt.pix_mp.width == W && coded.fmt.pix_mp.height == H, "coded format changed");
        require(coded.fmt.pix_mp.colorspace == rp.colorspace && coded.fmt.pix_mp.ycbcr_enc == rp.ycbcr_enc && coded.fmt.pix_mp.quantization == rp.quantization && coded.fmt.pix_mp.xfer_func == rp.xfer_func, "coded colorimetry differs");
        const unsigned ys = rp.plane_fmt[0].bytesperline;
        const unsigned uvs = rp.num_planes == 1 ? ys : rp.plane_fmt[1].bytesperline;
        require(ys >= W && uvs >= W && ys <= 8192 && uvs <= 8192, "unsupported stride");
        const unsigned ybytes = ys * H, uvbytes = uvs * (H / 2);
        std::vector<unsigned > used = rp.num_planes == 1 ? std::vector<unsigned > { ybytes + uvbytes } : std::vector<unsigned > { ybytes, uvbytes };
        for (unsigned i = 0; i < used.size(); ++i) require(rp.plane_fmt[i].sizeimage >= used[i], "format too small");
        control(d.fd, MVE_FRAME_RATE, FPS << 16, log);
        control(d.fd, V4L2_CID_MPEG_VIDEO_BITRATE, 2000000, log);
        control(d.fd, V4L2_CID_MPEG_VIDEO_H264_PROFILE, V4L2_MPEG_VIDEO_H264_PROFILE_BASELINE, log);
        v4l2_encoder_cmd trycmd {};
        trycmd.cmd = V4L2_ENC_CMD_STOP;
        checked(d.fd, VIDIOC_TRY_ENCODER_CMD, & trycmd, "TRY_ENCODER_CMD STOP");
        std::ofstream stream(dest / "video.h264", std::ios::binary);
        require(bool(stream), "stream open failed");
        Queue in(d.fd, IN, rp.num_planes), out(d.fd, OUT, 1);
        in.allocate(log, audit);
        out.allocate(log, audit);
        for (const auto & b : in.buffers) for (unsigned j = 0; j < used.size(); ++j) require(b[j].size >= used[j], "mapped raw buffer too small");
        unsigned queued = 0, returned = 0;
        bool draining = false, last = false;
        size_t total = 0;
        bool producerStopped = false;
        const auto epoch = std::chrono::steady_clock::now();
        auto nextSample = epoch;
        int64_t lastPts = - 1;
        std::vector<unsigned char> src(size_t(W) * H * 3 / 2);
        auto submit = [&](unsigned idx)->bool {
            require(!in.ownedByDriver[idx], "CPU attempted write while driver owns input");
            const bool streaming = in.streaming && out.streaming;
            log << "{\"event\":\"producer_enter\",\"frame\":" << queued << ",\"VPU_streaming\":" << (streaming ? "true" : "false") <<
            "}" << '\n';
            std::this_thread::sleep_until(nextSample);
            auto sampled = std::chrono::steady_clock::now();
            auto late = sampled - nextSample;
            auto skipped = std::chrono::duration_cast<std::chrono::milliseconds>(late).count() / 100;
            nextSample += std::chrono::milliseconds(100 * (skipped + 1));
            const auto sampleNs = uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(sampled.time_since_epoch()).count());
            auto candidate = producer(queued, sampleNs);
            require(std::chrono::steady_clock::now() - sampled < std::chrono::seconds(1), "Resident sampler blocked beyond1s");
            if (!candidate) {
                producerStopped = true;
                return false;
            }
            require(candidate->sampledNs >= sampleNs && candidate->sampledNs <= uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()), "Resident sampling timestamp outside callback");
            auto frame = std::move(candidate->frame);
            require(frame.nv12.size() == nv12FrameBytes && frame.encodedId == queued && frame.generatedNs > 0, "Resident frame invalid");
            src = std::move(frame.nv12);
            auto pts = int64_t(candidate->sampledNs - uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(epoch.time_since_epoch()).count())) / 1000;
            require(pts > lastPts, "Resident PTS not increasing");
            lastPts = pts;
            log << "{\"event\":\"sample_clock\",\"frame\":" << queued << ",\"sample_ns\":" << candidate->sampledNs << ",\"pts_us\":" <<
            pts << ",\"skipped_slots\":" << skipped << "}" << '\n';
            log << "{\"event\":\"source_frame\",\"encoded_id\":" << frame.encodedId << ",\"source_frame_id\":" << frame.sourceFrame <<
            ",\"invocation\":" << frame.invocation << ",\"generated_ns\":" << frame.generatedNs << ",\"repeated_source\":" <<
            (frame.repeatedSource ? "true" : "false") << ",\"inference_result\":" << (frame.inferenceResult ? "true" : "false") <<
            "}" << '\n';
            auto& b = in.buffers[idx];
            for (auto & p : b) memset(p.ptr, 0, p.size);
            auto * y = static_cast<unsigned char *>(b[0].ptr);
            auto * uv = rp.num_planes == 1 ? y + ybytes : static_cast<unsigned char *>(b[1].ptr);
            for (unsigned row = 0; row < H; ++row) memcpy(y + row * ys, src.data() + row * W, W);
            for (unsigned row = 0; row < H / 2; ++row) memcpy(uv + row * uvs, src.data() + size_t(W) * H + row * W, W);
            bool hostEqual = true;
            for (unsigned row = 0; row < H; ++row) hostEqual &= memcmp(y + row * ys, src.data() + row * W, W) == 0;
            for (unsigned row = 0; row < H / 2; ++row) hostEqual &= memcmp(uv + row * uvs, src.data() + size_t(W) * H + row * W, W) == 0;
            log << "{\"event\":\"host_copy_check\",\"frame\":" << queued << ",\"equal\":" << (hostEqual ? "true" : "false") <<
            "}" << '\n';
            require(hostEqual, "Host mapped input differs from current frame");
            in.queue(idx, used, queued, pts);
            log << "{\"event\":\"input_queued\",\"frame\":" << queued << ",\"pts_us\":" << pts << ",\"index\":" << idx <<
            "}" << '\n';
            ++queued;
            return true;
        };
        for (unsigned i = 0; i < out.buffers.size(); ++i) out.queue(i, { 0 });
        log << "{\"event\":\"input_prime_policy\",\"allocated_buffers\":" << in.buffers.size() << ",\"prime_count\":" <<
        primeInputs << "}" << '\n';
        for (unsigned i = 0; i < in.buffers.size() && i < primeInputs && queued < options.frameLimit; ++i) require(submit(i), "Resident producer stopped before prime");
        audit.take("prime");
        audit.take("before-capture-streamon");
        out.start();
        audit.take("after-capture-streamon");
        audit.take("before-raw-streamon");
        in.start();
        audit.take("after-raw-streamon");
        auto began = std::chrono::steady_clock::now();
        auto progress = began;
        bool firstCapture = false;
        while (!last || returned < queued) {
            bool moved = false;
            if (!last) {
                v4l2_buffer b {};
                v4l2_plane p[VIDEO_MAX_PLANES] {};
                while (out.dequeue(b, p)) {
                    require(p[0].data_offset <= p[0].bytesused && p[0].bytesused <= out.buffers[b.index][0].size, "capture length invalid");
                    unsigned size = p[0].bytesused - p[0].data_offset;
                    if (!firstCapture && size > 0) {
                        audit.take("first-capture");
                        firstCapture = true;
                        onFirstCapture();
                    }
                    OwnedPacket packet;
                    packet.ptsUs = b.timestamp.tv_sec * 1000000LL + b.timestamp.tv_usec;
                    packet.flags = b.flags;
                    packet.sequence = b.sequence;
                    auto * begin = static_cast<uint8_t *>(out.buffers[b.index][0].ptr) + p[0].data_offset;
                    packet.bytes.assign(begin, begin + size);
                    // owned copy before callback/requeue
                    stream.write(reinterpret_cast<const char *>(packet.bytes.data()), packet.bytes.size());
                    require(bool(stream), "stream write failed");
                    total += size;
                    consumer(std::move(packet));
                    log << "{\"event\":\"capture\",\"sequence\":" << b.sequence << ",\"pts_us\":" << b.timestamp.tv_sec * 1000000LL + b.timestamp.tv_usec <<
                    ",\"bytes\":" << size << ",\"flags\":" << b.flags << "}" << '\n';
                    moved = true;
                    last = b.flags& V4L2_BUF_FLAG_LAST;
                    if (last) break;
                    out.queue(b.index, { 0 });
                    memset(p, 0, sizeof(p));
                }
            }
            v4l2_buffer b {};
            v4l2_plane p[VIDEO_MAX_PLANES] {};
            while (returned < queued && in.dequeue(b, p)) {
                ++returned;
                moved = true;
                log << "{\"event\":\"input_returned\",\"index\":" << b.index << ",\"count\":" << returned << "}" << '\n';
                if (!producerStopped && queued < options.frameLimit) submit(b.index);
                memset(p, 0, sizeof(p));
            }
            if ((producerStopped || queued == options.frameLimit) && !draining) {
                v4l2_encoder_cmd c {};
                c.cmd = V4L2_ENC_CMD_STOP;
                checked(d.fd, VIDIOC_ENCODER_CMD, & c, "ENCODER_CMD STOP");
                draining = true;
                log << "{\"event\":\"drain_started\"}" << '\n';
            }
            auto now = std::chrono::steady_clock::now();
            if (moved) progress = now;
            require(now - began < std::chrono::seconds(100), "Resident total exceeds100s");
            require(firstCapture || now - began < std::chrono::seconds(5), "No first VPU capture within5s");
            require(now - progress < std::chrono::seconds(5), "Resident encoder stalled");
            if (!moved) {
                pollfd pfd { d.fd, POLLIN | POLLOUT | POLLPRI, 0 };
                int r = poll(& pfd, 1, 20);
                if (r < 0 || (pfd.revents & (POLLERR | POLLHUP | POLLNVAL))) {
                    audit.take("poll-error");
                    log << "{\"event\":\"poll_error\",\"return\":" << r << ",\"revents\":" << pfd.revents << ",\"errno\":" << (r < 0 ? errno : 0) <<
                    ",\"queued\":" << queued << ",\"returned\":" << returned << "}" << '\n';
                }
                require(r >= 0 || errno == EINTR, "poll failed");
                require(!(pfd.revents & (POLLERR | POLLHUP | POLLNVAL)), "poll device failure");
            }
        }

        require(producerStopped && queued >= 2 && returned == queued && last && total > 0, "incomplete resident stream");
        in.stop();
        out.stop();
        stream.close();
        require(bool(stream), "stream finalization failed");
        audit.take("completed");
        log << "{\"event\":\"encoding_complete\",\"queued\":" << queued << ",\"returned\":" << returned << ",\"last\":true,\"bytes\":" <<
        total << ",\"hdmi\":false,\"npu_owned_by_caller\":true}" << '\n';
        return { queued, returned, total, last };
    }

}

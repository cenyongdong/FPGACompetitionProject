// 推理模块：固定模型、CPU适配及公开SDK桥；保持单Engine和原计算、搬运顺序。
// 依赖通过本模块头文件声明；公开接口及异常传播遵循冻结基线。

#include "mixed_bridge.hpp"
#include "input_read_sdk.hpp"
#include "host_failure_evidence.hpp"
#include "failure_source_readback.hpp"
#include "host_stage_observation.hpp"
#include "producer_count_observation.hpp"
#include "tensor_identity_observation.hpp"
#include "mixed_fusion_baseline.hpp"
#include <icraft-xrt/dev/zg330_device.h>
#include <cstring>
#include <sstream>
#include "application_clock.hpp"
#include "content_diagnostic.hpp"
#include <icraft-xir/ops/ops.h>
#include <chrono>
#include <iomanip>
#include <mutex>
#include <ostream>

namespace pose_v1::mixed_candidate {
    namespace xir = icraft::xir;
    namespace xrt = icraft::xrt;
    namespace cpu = pose_v1::cpu_candidate;
    namespace {
        std::ostream* trace = nullptr;
        bool permit_hardware = false;
        xrt::Device allowed_device;
        uint64_t frame_id = 0;
        uint64_t invocation_id = 0;
        std::mutex trace_mutex;
        using Clock = std::chrono::steady_clock;
        void need(bool yes, const char* code, const char* detail) {
            if (!yes) throw cpu::Rejection(code, detail);
        }

        bool host(const xrt::Tensor& t) {
            return t.isOn(xrt::HostDevice::MemRegion()) && t.data().ptype() == xrt::PtrType::CPTR;
        }

        void bounds(const xrt::Tensor& t, const xir::TensorType& type, const char* code) {
            need(t.hasData() && t.dtype() == type, code, "Data or declared dtype differs");
            need(t.offset() <= t.chunk()->byte_size && type.bytes() <= t.chunk()->byte_size - t.offset(), code, "Tensor extends beyond allocated chunk");
            if (!host(t)) {
                need(permit_hardware && allowed_device.defined(), "memory", "Hardware memory is forbidden in this mode");
                need(t.memRegion().device().same_as(allowed_device), "memory", "Memory belongs to an unexpected device");
                need(t.data().ptype() == xrt::PtrType::ADDR || t.data().ptype() == xrt::PtrType::BOTH, "memory", "Unconfirmed device memory pointer kind");
            }
        }

        void event(const xir::Operation& op, const char* action, size_t index, const xrt::Tensor& source, const xrt::Tensor& dest, Clock::time_point begin) {
            std::lock_guard<std::mutex > guard(trace_mutex);
            if (!trace) return;
            * trace << "{\"frame_id\":" << frame_id << ",\"invocation\":" << invocation_id << ",\"op_id\":" << op->op_id <<
            ",\"action\":" << std::quoted(action) << ",\"index\":" << index << ",\"bytes\":" << source.dtype().bytes() <<
            ",\"elapsed_ms\":" << std::chrono::duration<double, std::milli>(Clock::now() - begin).count() << ",\"source\":";
            tensor_info(* trace, source);
            * trace << ",\"destination\":";
            tensor_info(* trace, dest);
            * trace << "}\n";
            trace->flush();
        }



        std::string identityType(const xir::TensorType& type) {
            std::ostringstream f;
            f << "{\"FP32\":" << (type->element_dtype.isFP32() ? "true" : "false") << ",\"bytes\":" << type.bytes() <<
            ",\"shape\":[";
            for (size_t i = 0; i < type->shape.size(); ++i) {
                if (i) f << ',';
                f << type->shape[i];
            }
            f << "],\"layout\":\"";
            for (size_t i = 0; i < type->shape.size(); ++i) {
                f << type->layout.getAxisCharName(int64_t(i));
            }
            f << "\",\"distributions\":[";
            bool first = true;
            for (const auto & d : type->merged_distrs) {
                if (!first) f << ',';
                first = false;
                f << "{\"uvalue\":" << int(d->uvalue) << ",\"axes\":[";
                bool a = true;
                for (auto axis : d->merged_axis) {
                    if (!a) f << ',';
                    a = false;
                    f << axis;
                }
                f << "],\"valid_mask\":\"";
                for (bool bit : d->valid_mask) f << (bit ? '1' : '0');
                f << "\"}";
            }
            f << "]}";
            return f.str();
        }

        pose::tensor_identity::Storage identityStorage(const xrt::Tensor& t, const xir::TensorType& declared) {
            pose::tensor_identity::Storage s;
            s.tensor = reinterpret_cast<uintptr_t>(t.operator->());
            s.region = reinterpret_cast<uintptr_t>(t.memRegion().operator->());
            s.chunk = reinterpret_cast<uintptr_t>(t.chunk().operator->());
            s.device = reinterpret_cast<uintptr_t>(t.memRegion().device().operator->());
            s.offset = t.offset();
            s.capacity = t.chunk()->byte_size;
            s.bytes = t.dtype().bytes();
            s.declaredMatches = t.dtype() == declared;
            s.ownerMatches = host(t) || (allowed_device.defined() && t.memRegion().device().same_as(allowed_device));
            auto kind = t.data().ptype();
            s.kind = kind == xrt::PtrType::CPTR ? "CPTR" : kind == xrt::PtrType::ADDR ? "ADDR" : "BOTH";
            s.address = kind == xrt::PtrType::CPTR ? reinterpret_cast<uintptr_t>(t.data().cptr()) : t.data().addr();
            s.regionKey = std::string(t.memRegion()->typeKey());
            s.type = identityType(t.dtype());
            s.declaredType = identityType(declared);
            return s;
        }

        void observeIdentity(const xir::Operation& op, size_t slot, bool after, const xrt::Tensor& source, const xrt::Tensor& dest, const xir::TensorType& declared) {
            if (!pose::tensor_identity::enabled()) return;
            pose::tensor_identity::Pair pair;
            pair.source = identityStorage(source, declared);
            pair.destination = identityStorage(dest, declared);
            pair.sameRegion = source.memRegion().same_as(dest.memRegion());
            pair.sameDevice = source.memRegion().device().same_as(dest.memRegion().device());
            pose::tensor_identity::sample(frame_id, invocation_id, op->op_id, slot, after, std::move(pair));
        }

        template < class Op > void add() {
            xrt::BackendOpRegisterHelper<Op, xrt::HostBackend>().set_init([](const Op& op, xrt::HostBackend) {
                cpu::validate_spec(op);
            }).set_forward([](const Op& op, const std::vector<xrt::Tensor> & inputs, const std::vector<xrt::Tensor> & outputs, xrt::HostBackend) {
                return forward(op, inputs, outputs);
            });
        }

    }

    void configure(std::ostream* log, bool hardware, xrt::Device device) {
        std::lock_guard<std::mutex > guard(trace_mutex);
        need(!hardware || device.defined(), "memory", "Hardware bridge requires opened device identity");
        trace = log;
        permit_hardware = hardware;
        allowed_device = device;
    }

    void set_frame(uint64_t frame, uint64_t invocation) {
        std::lock_guard<std::mutex > guard(trace_mutex);
        frame_id = frame;
        invocation_id = invocation;
    }

    void tensor_info(std::ostream& out, const xrt::Tensor& t) {
        const bool allocated = t.hasData();
        out << "{\"allocated\":" << (allocated ? "true" : "false") << ",\"bytes\":" << t.dtype().bytes();
        if (allocated) {
            const auto kind = t.data().ptype();
            out << ",\"pointer\":" << std::quoted(kind == xrt::PtrType::CPTR ? "CPTR" : kind == xrt::PtrType::ADDR ? "ADDR" : kind == xrt::PtrType::BOTH ? "BOTH" : "unknown") <<
            ",\"region\":" << std::quoted(std::string(t.memRegion()->typeKey())) << ",\"offset\":" << t.offset() << ",\"chunk_bytes\":" <<
            t.chunk()->byte_size;
        }

        out << '}';
    }

    // 1. 仅注册当前图缺失的算子；原Gather注册必须保持。
    void register_ops(const xir::Network& graph, xrt::HostBackend backend) {
        for (int64_t id : { 188, 192, 437 }) {
            auto op = graph.getOpById(id);
            cpu::validate_spec(op);
            need(!backend.isOpSupported(op) && !backend.getInitFunc(op) && !backend.getForwardFunc(op), "registry", "Existing or partial registration; never override");
        }

        auto gather = graph.getOpById(442);
        need(gather.is < xir::Gather>() && backend.isOpSupported(gather) && backend.getInitFunc(gather) && backend.getForwardFunc(gather), "registry", "Original Gather baseline changed");
        auto gi = backend.getInitFunc(gather).value().target_type().hash_code();
        auto gf = backend.getForwardFunc(gather).value().target_type().hash_code();
        add<xir::TopK>();
        add<xir::GatherElements>();
        need(backend.getInitFunc(gather).value().target_type().hash_code() == gi && backend.getForwardFunc(gather).value().target_type().hash_code() == gf, "registry", "Gather callback type changed");
        for (int64_t id : { 188, 192, 437 }) {
            auto op = graph.getOpById(id);
            need(backend.isOpSupported(op) && backend.getInitFunc(op) && backend.getForwardFunc(op), "registry", "Mixed registration not visible");
        }

    }

    std::vector<xrt::Tensor> forward(const xir::Operation& op, const std::vector<xrt::Tensor> & inputs, const std::vector<xrt::Tensor> & supplied) {
        {
            forward_clock::Span t("bridge.spec", op->op_id);
            cpu::validate_spec(op);
        }

        size_t expected = 0;
        for (const auto & v : op->inputs) if (!v.isParams()) ++expected;
        need(inputs.size() == expected, "arity", "Runtime input count differs");
        need(supplied.empty() || supplied.size() == op->outputs.size(), "output", "Partial output buffers cannot be mapped safely");
        std::vector<xrt::Tensor> staged;
        pose::stage_observation::Call observation(frame_id, invocation_id, op->op_id);
        size_t index = 0;
        for (const auto & value : op->inputs) {
            if (value.isParams()) continue;
            // Real/synthetic parameters remain in the original op.
            const auto& src = inputs[index];
            bounds(src, value.tensorType(), "storage");

            auto begin = Clock::now();
            {
                forward_clock::Span t("bridge.wait", op->op_id, index);
                need(src.waitForReady(std::chrono::milliseconds(10000)), "ready", "SDK input wait timed out");
            }
            const auto waitEnd = pose::stage_observation::now();


            const auto allocation_sample = forward_clock::sample();
            auto dst = xrt::Tensor(value.tensorType()).mallocOn(xrt::HostDevice::MemRegion());
            forward_clock::record("bridge.allocate", op->op_id, index, allocation_sample, forward_clock::sample());
            // SDK owns reads and cross-region copy semantics. Never dereference ADDR/BOTH.

            observeIdentity(op, index, false, src, dst, value.tensorType());
            const auto copyBegin = pose::stage_observation::now();
            {
                forward_clock::transfer("bridge.copy", op->op_id, index, value.tensorType().bytes(), host(src) ? "host_to_host" : "device_to_host");
                forward_clock::Span t("bridge.copy", op->op_id, index);
                if (host(src)) {
                    dst.copyFrom(0, src, 0, value.tensorType().bytes());
                } else {
                    pose::input_read::intoHost(src, dst);
                }
            }
            const auto copyEnd = pose::stage_observation::now();

            pose::stage_observation::Info metadata;
            metadata.slot = index;
            metadata.bytes = size_t(value.tensorType().bytes());
            metadata.sourceOffset = src.offset();
            metadata.sourceCapacity = src.chunk()->byte_size;
            metadata.sourceRegion = std::string(src.memRegion()->typeKey());
            const auto kind = src.data().ptype();
            metadata.sourceKind = kind == xrt::PtrType::CPTR ? "CPTR" : kind == xrt::PtrType::ADDR ? "ADDR" : "BOTH";
            if (kind != xrt::PtrType::CPTR) metadata.sourceAddress = src.data().addr();
            metadata.hostPointer = reinterpret_cast<uintptr_t>(dst.data().cptr());
            metadata.hostChunk = reinterpret_cast<uintptr_t>(dst.chunk().operator->());
            metadata.hostOffset = dst.offset();
            metadata.hostCapacity = dst.chunk()->byte_size;
            metadata.hostRegion = std::string(dst.memRegion()->typeKey());
            metadata.waitBegin = std::chrono::duration_cast<std::chrono::nanoseconds>(begin.time_since_epoch()).count();
            metadata.waitEnd = waitEnd;
            metadata.copyBegin = copyBegin;
            metadata.copyEnd = copyEnd;
            observation.afterCopy(std::move(metadata), dst.data().cptr());
            observeIdentity(op, index, true, src, dst, value.tensorType());
            if (content_diagnostic::enabled()) content_diagnostic::capture(dst, "bridge_input", op->op_id, index);
            staged.push_back(dst);
            event(op, "input_to_host", index, src, dst, begin);
            ++index;
        }

        for (size_t i = 0; i < supplied.size(); ++i) bounds(supplied[i], op->outputs[i].tensorType(), "output");
        const auto compute_sample = forward_clock::sample();
        std::vector<xrt::Tensor> computed;
        try {
            observation.validate();
            computed = cpu::forward(op, staged, {});
        } catch (const std::exception& error) {
            // Successful path unchanged. All snapshots own bytes from existing Host staging.
            const auto errorTime = pose::stage_observation::now();
            if (pose::failure_evidence::enabled()) try {
                std::vector<pose::failure_evidence::Blob > blobs;
                for (size_t i = 0; i < staged.size(); ++i) {
                    const auto& t = staged[i];
                    need(host(t) && t.dtype()->element_dtype.isFP32(), "capture", "Failure input must be Host CPTR FP32");
                    bounds(t, t.dtype(), "capture");
                    const auto bytes = t.dtype().bytes();
                    need(bytes > 0 && bytes <= 1024 * 1024, "capture", "Failure input byte bound");
                    pose::failure_evidence::Blob b;
                    b.slot = i;
                    b.offset = t.offset();
                    b.chunkBytes = t.chunk()->byte_size;
                    for (int64_t d : t.dtype()->shape) b.shape.push_back(d);
                    for (size_t a = 0; a < t.dtype()->shape.size(); ++a) b.layout += t.dtype()->layout.getAxisCharName(int64_t(a));
                    b.distributions = t.dtype()->merged_distrs.size();
                    b.bytes.resize(size_t(bytes));
                    std::memcpy(b.bytes.data(), t.data().cptr(), size_t(bytes));
                    blobs.push_back(std::move(b));
                }
                std::ostringstream declarations;
                declarations << '[';
                size_t slot = 0;
                for (const auto & v : op->inputs) {
                    if (slot) declarations << ',';
                    declarations << "{\"slot\":" << slot ++<< ",\"parameter\":" << (v.isParams() ? "true" : "false") << ",\"bytes\":" <<
                    v.tensorType().bytes() << ",\"shape\":[";
                    for (size_t j = 0; j < v.tensorType()->shape.size(); ++j) {
                        if (j) declarations << ',';
                        declarations << v.tensorType()->shape[j];
                    }
                    declarations << "]}";
                }
                declarations << ']';
                pose::failure_evidence::save(frame_id, invocation_id, op->op_id, error.what(), blobs, declarations.str());
                observation.saveFailure(pose::stage_observation::failureRoot(), errorTime);
                size_t totalBytes = 0;
                for (const auto & b : blobs) totalBytes += b.bytes.size();
                pose::source_diagnostic::capture(frame_id, invocation_id, op->op_id, inputs, allowed_device, permit_hardware, totalBytes);
            } catch (const std::exception& e) {
                pose::failure_evidence::noteCaptureError(e.what());
            } catch (...) {
                pose::failure_evidence::noteCaptureError("Unknown failure capture error");
            }
            throw;
            // Preserve the original CPU exception, never recover/retry or edit indices.
        }

        forward_clock::record("bridge.cpu", op->op_id, 0, compute_sample, forward_clock::sample());
        if (content_diagnostic::enabled()) for (size_t i = 0; i < computed.size(); ++i) content_diagnostic::capture(computed[i], "bridge_result", op->op_id, i);
        if (supplied.empty()) return computed;
        std::vector<xrt::Tensor> returned;
        for (size_t i = 0; i < computed.size(); ++i) {
            auto begin = Clock::now();
            auto target = supplied[i];
            {
                forward_clock::transfer("bridge.writeback", op->op_id, i, computed[i].dtype().bytes(), host(target) ? "host_to_host" : "host_to_device");
                forward_clock::Span t("bridge.writeback", op->op_id, i);
                target.copyFrom(0, computed[i], 0, computed[i].dtype().bytes());
            }
            target.setReady(true);
            returned.push_back(target);
            event(op, "host_to_output", i, computed[i], target, begin);
        }

        return returned;
    }

}
